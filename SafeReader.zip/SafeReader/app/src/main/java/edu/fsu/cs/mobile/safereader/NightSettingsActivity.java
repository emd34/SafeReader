package edu.fsu.cs.mobile.safereader;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

/**
 * Created by Kevin on 3/23/2018.
 */

public class NightSettingsActivity extends AppCompatActivity {
    int bgColor, txtColor;
    Button black, gray, dBlue, purple, white, lBlue, gold, green;
    CheckBox autoNight;
    boolean nightModeAuto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_settings);

        black = findViewById(R.id.button3);
        gray = findViewById(R.id.button4);
        dBlue = findViewById(R.id.button5);
        purple = findViewById(R.id.button6);
        white = findViewById(R.id.button7);
        gold = findViewById(R.id.button8);
        lBlue = findViewById(R.id.button9);
        green = findViewById(R.id.button10);

        autoNight = findViewById(R.id.autoNight);

        bgColor = 1;
        txtColor = 1;

        black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bgColor = 1;
            }
        });

        gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bgColor = 2;
            }
        });

        dBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bgColor = 3;
            }
        });

        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bgColor = 4;
            }
        });

        white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtColor = 1;
            }
        });

        gold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtColor = 2;
            }
        });

        lBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtColor = 3;
            }
        });

        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtColor = 4;
            }
        });
    }

    public void itemClicked(View v){
        if(autoNight.isChecked()){
            nightModeAuto = true;
        }
        else
            nightModeAuto = false;
    }

    public void checkAutoNightMode(boolean auto){
        if(auto){

        }
        else{
        }
    }
}
