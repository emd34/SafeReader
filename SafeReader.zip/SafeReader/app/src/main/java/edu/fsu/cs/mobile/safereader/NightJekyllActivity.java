package edu.fsu.cs.mobile.safereader;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;


public class NightJekyllActivity extends AppCompatActivity implements SensorEventListener{
    boolean brightness, scale;

    public TextView text;
    SensorManager sensorManager;
    Sensor sensor;

    View view;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_night_jekyll);

        text = findViewById(R.id.nightJekyll);
        text.setText(R.string.jekyll);
        text.setTextSize(14);

        view = findViewById(R.id.rootView4);
        view.setBackgroundColor(Color.BLACK);
        text.setTextColor(Color.WHITE);

        brightness = false;
        scale = false;

        sensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        Settings.System.putInt(getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);



    }

    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    protected void onResume(){
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY){
            float prox = sensorEvent.values[0];

            WindowManager.LayoutParams brightnessParameter = NightJekyllActivity.this.getWindow().getAttributes();


            if(prox >= 0.0 && prox <= 0.5){
                if(scale)
                    text.setTextSize(16);

                if(brightness) {
                    brightnessParameter.screenBrightness = 0;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 0.5 && prox <= 1.0){
                if(scale)
                    text.setTextSize(18);

                if(brightness){
                    brightnessParameter.screenBrightness = (float)0.05;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 1.0 && prox <= 1.5){
                if(scale)
                    text.setTextSize(20);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.1;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 1.5 && prox <= 2.0){
                if(scale)
                    text.setTextSize(22);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.15;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 2.0 && prox <= 2.5) {
                if(scale)
                    text.setTextSize(24);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.2;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 2.5 && prox <= 3.0) {
                if(scale)
                    text.setTextSize(26);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.25;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 3.0 && prox <= 3.5) {
                if(scale)
                    text.setTextSize(28);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.3;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 3.5 && prox <= 4.0) {
                if(scale)
                    text.setTextSize(30);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.35;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 4.0 && prox <= 4.5) {
                if(scale)
                    text.setTextSize(32);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.4;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 4.5 && prox <= 5.0) {
                if (scale)
                    text.setTextSize(34);

                if (brightness) {
                    brightnessParameter.screenBrightness = (float) 0.45;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 5.0 && prox <= 5.5) {
                if(scale)
                    text.setTextSize(36);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.5;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 5.5 && prox <= 6.0) {
                if(scale)
                    text.setTextSize(38);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.55;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 6.0 && prox <= 6.5) {
                if(scale)
                    text.setTextSize(40);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.60;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 6.5 && prox <= 7.0) {
                if(scale)
                    text.setTextSize(42);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.65;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 7.0 && prox <= 7.5) {
                if(scale)
                    text.setTextSize(44);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.7;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 7.5 && prox <= 8.0) {
                if(scale)
                    text.setTextSize(48);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.75;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 8.0 && prox <= 8.5) {
                if(scale)
                    text.setTextSize(50);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.8;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 8.5 && prox <= 9.0) {
                if(scale)
                    text.setTextSize(52);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.85;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else if(prox > 9.0 && prox <= 9.5) {
                if(scale)
                    text.setTextSize(54);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.9;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
            else{
                if(scale)
                    text.setTextSize(56);

                if(brightness) {
                    brightnessParameter.screenBrightness = (float) 0.95;
                    getWindow().setAttributes(brightnessParameter);
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {}

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.settings, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.night:
                Toast.makeText(getApplicationContext(), "NightMode disabled",
                        Toast.LENGTH_SHORT).show();
                finish();
                break;
            case R.id.brightness:
                if(brightness){
                    Toast.makeText(getApplicationContext(), "Auto Brightness disabled",
                            Toast.LENGTH_SHORT).show();
                    brightness = false;
                }
                else{
                    Toast.makeText(getApplicationContext(), "Auto Brightness enabled",
                            Toast.LENGTH_SHORT).show();
                    brightness = true;
                }
                break;
            case R.id.autoscale:
                if(scale){
                    Toast.makeText(getApplicationContext(), "Auto TextScaling disabled",
                            Toast.LENGTH_SHORT).show();
                    scale = false;
                }
                else{
                    Toast.makeText(getApplicationContext(), "Auto TextScaling enabled",
                            Toast.LENGTH_SHORT).show();
                    scale = true;
                }
        }
        return true;
    }
}